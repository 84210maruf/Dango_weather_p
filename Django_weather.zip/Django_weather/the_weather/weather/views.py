import requests
from django.shortcuts import render

from .models import City
from .forms import CityForm




def cityCheck(request,url):


	CityName = request.POST.get('name')
	
	dict1 = requests.get(url.format(CityName)).json()
	print(type(dict1))
	c=0
	for x in dict1:
			c += 1

	print(c)
	if c==2:
		return False
	else:
		return True
	



def index(request):
	
	url = 'http://api.openweathermap.org/data/2.5/weather?q={}&units=imperial&appid=22b33262727cff033bcc69ec0a3f2314'
	
	error_message = None
	if cityCheck(request,url) == True:
			if request.method == 'POST':
				#print(request.POST)
				form = CityForm(request.POST)	
				form.save()
	else:
		error_message = 'City Not Founded'
		#print(error_message)

	print(error_message)

	form = CityForm()


	cities = City.objects.all()
	
	
	#print(type(cities)
	
	weather_data = []
	print("=================================")
	for city in cities:
		r = requests.get(url.format(city)).json()
		#print(type(r))
		#print('--------city--------')
		city_weather = {
			'city': city.name,
			#If problem with Main then you need to delete same irrelavent data from database 
			'temperature': r['main']['temp'],
			'description': r['weather'][0]['description'],
			'icon': r['weather'][0]['icon'],
		}
		#if print all the cities from database then append weather data
		#weather_data.append(city_weather)
		#print(weather_data)

	print(type(city_weather))
	
	context = {
	'weather_data' : weather_data,
	'form': form,
	'current_city':city_weather,
	'error_message':error_message,
	}
	#print(context)
	return render(request, 'weather/weather.html',context)