# Weather_Project_Django
 Its a weather ditection project with python and django
